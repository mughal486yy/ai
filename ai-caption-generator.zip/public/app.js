const topic=document.querySelector('#topic'),tone=document.querySelector('#tone'),platform=document.querySelector('#platform');
const result=document.querySelector('#result'),caption=document.querySelector('#caption'),tags=document.querySelector('#tags');
const btn=document.querySelector('#generate');

function makeCaption(t,style,p){
 const clean=t.trim();
 const hooks={
  Viral:`POV: ${clean} 🚀\n\nI didn’t come this far to play small. The next level starts NOW. 🔥`,
  Attitude:`They can watch. I’ll keep building. 😈\n\n${clean} — and remember the name.`,
  Sad:`Some moments look perfect on the outside, but only you know what they cost. 🥀\n\n${clean}`,
  Funny:`Well… that escalated quickly 😂\n\n${clean}. Anyway, we move!`,
  Professional:`Proud to share this milestone: ${clean}.\n\nGrateful for the journey, focused on what comes next.`
 };
 return hooks[style] || hooks.Viral;
}
function makeTags(style,p){
 const base={Viral:["#viral","#trending","#fyp","#explore","#viralvideo"],Attitude:["#attitude","#mindset","#sigma","#nofilter","#boss"],Sad:["#sad","#heartbreak","#deep","#feelings","#alone"],Funny:["#funny","#comedy","#lol","#memes","#fyp"],Professional:["#success","#growth","#creator","#motivation","#goals"]};
 return [...base[style],`#${p.toLowerCase()}`];
}
btn.onclick=()=>{
 if(!topic.value.trim()){topic.focus();return}
 caption.textContent=makeCaption(topic.value,tone.value,platform.value);
 tags.innerHTML=makeTags(tone.value,platform.value).map(x=>`<span>${x}</span>`).join('');
 result.classList.remove('hidden');
 result.scrollIntoView({behavior:'smooth',block:'nearest'});
};
document.querySelector('#copy').onclick=async()=>{
 const text=caption.textContent+"\n\n"+[...tags.querySelectorAll('span')].map(x=>x.textContent).join(' ');
 await navigator.clipboard.writeText(text);
 document.querySelector('#copy').textContent='Copied ✓';
 setTimeout(()=>document.querySelector('#copy').textContent='Copy',1200);
};
