import http from "http";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const port = process.env.PORT || 3000;

const server = http.createServer((req,res)=>{
  let file = req.url === "/" ? "/index.html" : req.url;
  const filePath = path.join(__dirname, "public", file);
  fs.readFile(filePath, (err,data)=>{
    if(err){ res.writeHead(404); return res.end("Not found"); }
    const ext=path.extname(filePath);
    const types={".html":"text/html; charset=utf-8",".css":"text/css; charset=utf-8",".js":"text/javascript; charset=utf-8"};
    res.writeHead(200,{"Content-Type":types[ext]||"text/plain"});
    res.end(data);
  });
});
server.listen(port,()=>console.log(`AI Caption Generator running on ${port}`));
