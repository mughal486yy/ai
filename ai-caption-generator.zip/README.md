# CaptionForge — AI Caption Generator

A lightweight creator-focused caption and hashtag generator.

## Run locally
```bash
npm start
```
Then open `http://localhost:3000`.

## Railway
This app automatically uses Railway's `PORT` environment variable and can be deployed as a Node.js service.
